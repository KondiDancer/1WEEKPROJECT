-- phpMyAdmin SQL Dump
-- version 3.4.10.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2018 at 09:59 AM
-- Server version: 5.5.21
-- PHP Version: 5.6.18

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sberk`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `student_uob` int(8) NOT NULL,
  `student_name` varchar(256) NOT NULL,
  `yos` enum('1','2','3','4','5') NOT NULL,
  `group_name` varchar(256) DEFAULT NULL,
  `tutor_uob` int(8) DEFAULT NULL,
  PRIMARY KEY (`student_uob`),
  KEY `group_name` (`group_name`),
  KEY `tutor_uob` (`tutor_uob`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_uob`, `student_name`, `yos`, `group_name`, `tutor_uob`) VALUES
(17010101, 'Test student', '1', 'Test group', 12010101),
(17010102, 'Second teststudent', '1', 'Test group', 12010101);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`group_name`) REFERENCES `groups` (`group_name`),
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`tutor_uob`) REFERENCES `tutors` (`tutor_uob`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
