UPDATE `tutors` SET `group_id` = '1' WHERE `tutors`.`tutor_id` = 1; 

SELECT * FROM groups JOIN students, tutors WHERE groups.group_id=tutors.group_id AND tutors.tutor_id=students.tutor_id AND students.group_id=tutors.group_id;

SELECT * FROM groups JOIN students USING (group_id)

SELECT * FROM groups NATURAL JOIN students, tutors WHERE tutors.tutor_id = students.tutor_id AND tutors.tutor_id = groups.group_id AND students.group_id = groups.group_id;

FINAL:

SELECT groups.group_name, groups.yos, students.student_name, students.student_uob, tutors.tutor_name, tutors.tutor_uob FROM students, tutors, groups WHERE students.group_id = groups.group_id AND tutors.group_id = groups.group_id 

CREATE TABLE students (
	student_uob INT(8) NOT NULL PRIMARY KEY,
    student_name VARCHAR(256) NOT NULL,
	yos enum('1','2','3','4','5') NOT NULL,
	group_name VARCHAR(256),
	tutor_uob INT(8),
	FOREIGN KEY (group_name) REFERENCES groups(group_name),
	FOREIGN KEY (tutor_uob) REFERENCES tutors(tutor_uob)
);

CREATE TABLE tutors (
	tutor_uob INT(8) NOT NULL PRIMARY KEY,
    tutor_name VARCHAR(256) NOT NULL,
	group_name VARCHAR(256),
	FOREIGN KEY (group_name) REFERENCES groups(group_name)
);

CREATE TABLE groups (
    group_name VARCHAR(256) NOT NULL PRIMARY KEY,
	yos enum('1','2','3','4','5') NOT NULL
);

ALTER TABLE `tutors`  ADD UNIQUE INDEX `group_name_unique` (`group_name`);
