package PATProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sberk
 */
public class DbConnect{
    public static void main(String[] args) {
        Connection con = null; // The database connection object
        Statement stmt = null;
        ResultSet rs = null;
        try {        
            Class.forName ("com.mysql.jdbc.Driver"); // Loading the MySQL JDBC Driver
            /*FOR XAMPP
            con  = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/pat", "root", "");
            */
            /* FOR LAMP */
            Class.forName ("com.mysql.jdbc.Driver"); // Loading the MySQL JDBC Driver
            con  = DriverManager.getConnection(
                    "jdbc:mysql://lamp.scim.brad.ac.uk:3306/sberk", "dpreciko", "Marcinp98676075");
            
            stmt = con.createStatement();
            String query1 = "SELECT groups.group_name, groups.yos, students.student_name, students.student_uob, tutors.tutor_name, tutors.tutor_uob FROM students, tutors, groups WHERE students.group_name = groups.group_name AND tutors.group_name = groups.group_name ";
                    
            rs = stmt.executeQuery(query1);
            while(rs.next()) {
                String group_name = rs.getString("group_name");
                int group_yos = rs.getInt("yos");
                String student_name = rs.getString("student_name");
                int student_uob = rs.getInt("student_uob");
                String tutor_name = rs.getString("tutor_name");
                int tutor_uob = rs.getInt("tutor_uob");
                System.out.println("Group name: " + group_name + " \nGroup Year of Study: " + group_yos + " Student name: " + student_name + " Student UOB: " + student_uob + " Tutor name: " + tutor_name + " Tutor UOB: " + tutor_uob);
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DbConnect.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DbConnect.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally {
            if(con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DbConnect.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DbConnect.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DbConnect.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
