/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PATProject;

/**
 *
 * @author dpreciko
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Scanner;
import java.util.regex.*;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.regex.*;
import java.lang.Object;

/**
 *
 * @author dpreciko
 */
public class AddGroup {

    private static String groupName;
    private static String yearOfStudy;
    private static String tutorUob;
    static ResultSet rs = null;
    public void createGroup() {

        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter group name: ");

        while (true) {

            groupName = input.nextLine();
            
            if (AddS.isGroupNameUnique(groupName)) {
                break;
            } else {
                System.out.println("This name already exists.");
                System.out.print("\nTry different name:");
            }
        }
        System.out.print("Enter the year of study for a group [" + groupName + "]: ");
        String y = input.nextLine();
        yearOfStudy = y;
        is_year_valid(yearOfStudy);

        ArrayList<String> buffer = new ArrayList<String>();
        System.out.println("yos = " + yearOfStudy);
        while (true) {
            System.out.println("Add 4-8 students using the UoB number.\ntype \"finish\" to finish adding.");
            for (int i = 0; i <= 8; i++) {
                String student;
                System.out.print("student [" + (i + 1) + "]: ");
                student = input.nextLine();

                if (student.equals("finish")) {
                    break;
                } else if (!AddS.is_uob_valid(student)) {
                    String correct = "";
                    while (!AddS.is_uob_valid(correct)) {
                        System.out.print("Wrong Input.\nPlease enter the correct UoB number for student [" + (i + 1) + "]:");
                        correct = input.nextLine();
                    }
                } else {

                    buffer.add(student);

                }
                
                

            }
            if (!check_buffer(buffer)) {
                continue;
            }
            while(true){
            System.out.println("Enter Group Tutor's UoB number: ");
                tutorUob = input.nextLine();
                if(check_tutor(tutorUob))
                {
                    break;
                }
                
            }
                
            add_buffer_to_database(buffer);

        print_results(buffer);

        }

        
    }

    public void setGroupName(String groupName) {

        this.groupName = groupName;

    }

    public void setYearofStudy(String yearOfStudy) {

        this.yearOfStudy = yearOfStudy;

    }

    public String getGroupName() {

        return groupName;

    }

    public String getYearOfStudy() {

        return yearOfStudy;

    }

    public static void is_year_valid(String yearOfStudy) {
        Scanner scan = new Scanner(System.in);
        String yos = yearOfStudy;
        while (!is_yos_valid(yos)) {

            System.out.println("Wrong input. \nPlease enter a year between 1 and 5:");
            yos = scan.nextLine();

        }

    }

    public static boolean is_yos_valid(String student_yos) {
        Pattern p = Pattern.compile("[1-5]{1}");
        Matcher m = p.matcher(student_yos);
        return m.matches();
    }

    public static boolean is_students_number_correct(int students) {
        if (students < 4) {
            return false;
        } else {
            return true;
        }
    }

    public static boolean does_student_exist(String student) {
        for (int i = 0; i < AddS.get_all_student_uob().size(); i++) {
            if (student.equals(AddS.get_all_student_uob().get(i))) {
                return true;
            }

        }
        return false;
    }
    public static boolean does_tutor_exist(String student) {
        for (int i = 0; i < AddS.get_all_tutors_uob().size(); i++) {
            if (student.equals(AddS.get_all_tutors_uob().get(i))) {
                return true;
            }

        }
        return false;
    }

    public static boolean does_student_has_group(String student_uob) {
       AddS.connect();
        try {
            String query_selectgroup = "SELECT `group_name` FROM `students` WHERE `student_uob` = " + student_uob;
            rs = AddS.connect().executeQuery(query_selectgroup);
         
            
            rs.next();
            if((rs.getString("group_name") == null)){
               // rs.bef
                return true;
            
             
           }
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            AddS.disconnect();
        }
        return false;

    }
    public static boolean does_tutor_has_group(String tutor_uob) {
       AddS.connect();
        try {
            String query_selectgroup = "SELECT `group_name` FROM `tutors` WHERE `tutor_uob` = " + tutor_uob;
            rs = AddS.connect().executeQuery(query_selectgroup);
         
            
            rs.next();
            if((rs.getString("group_name") == null)){
               
                return true;
            
             
           }
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            AddS.disconnect();
        }
        return false;

    }
    
    public static boolean is_student_year_correct(String student_uob){
        AddS.connect();
        try {
            String query_select_year = "SELECT `yos` FROM `students` WHERE `student_uob` = " + student_uob;
            AddS.rs = AddS.connect().executeQuery(query_select_year);
            AddS.rs.next();
            if ( !AddS.rs.getString("yos").equals(yearOfStudy) ) { 
               
                  return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            AddS.disconnect();
        }
        return true;
        
    }

    public static boolean check_buffer(ArrayList<String> buf) {

        if (!is_students_number_correct(buf.size())) {
            System.out.println("\nYou added less than 4 students to the group.");
            return false;
        }
        for (int i = 0; i < buf.size(); i++) {

            if (!does_student_exist(buf.get(i))) {
                System.out.println("Wrong input. Student with number [" + buf.get(i) + "] doesn't exist.");
                return false;
            }
            if ( !(does_student_has_group(buf.get(i))) ){
                System.out.println("Wrong input. Student with number [" + buf.get(i) + "] already has a group");
                return false;
            }
            if ( !is_student_year_correct(buf.get(i)) ){
                System.out.println("Wrong input. Student with number [" + buf.get(i) + "] isn't from year " + yearOfStudy + ".");  
                return false;
            }

        }

        return true;
    }
    
    public static boolean check_tutor(String tutor_uob){
        if(does_tutor_exist(tutor_uob)){
            
        }
        else{
            System.out.println("Wrong input. Tutor with UoB number \"" + tutor_uob + " doesn't exist.");
            return false;
        }
        if(does_tutor_has_group(tutor_uob)){
            
        }
        else{
            System.out.println("Wrong input. Tutor with UoB number \"" + tutor_uob + " Already has a group.");
            return false;
        }
        return true;
    }
      
    
    public static void add_buffer_to_database(ArrayList<String> buf){
        
        AddS.connect();
        
        try {
            for(int i = 0 ; i < buf.size() ; i++){
            String query_update = "UPDATE `students` SET `group_name` = \"" + groupName + "\",`tutor_uob` = " + tutorUob + " WHERE `student_uob` = " + buf.get(i);
            AddS.connect().executeUpdate(query_update);
            String tutor_update = "UPDATE `tutors` SET `group_name` = \"" + groupName + "\" WHERE `tutor_uob` = " + tutorUob;
            AddS.connect().executeUpdate(tutor_update);
            }
 
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        finally{
            AddS.disconnect();
        }
        
    }

    public static void print_results(ArrayList<String> results){

        AddS.connect();
        
        try {
           
            for(int i = 0 ; i < results.size() ; i++){
            String query_selectuob = "SELECT `student_name` FROM `students` WHERE `student_uob` = " + results.get(i);
            String uob = results.get(i);
            String name;
            AddS.rs = AddS.connect().executeQuery(query_selectuob);
            AddS.rs.next();
            name = AddS.rs.getString("student_name");
            System.out.println(i + ". Student Name: " + name + ", Student UoB number: " + uob );
            }
            String query_tutor = "SELECT `tutor_name` FROM `tutors` WHERE `tutor_uob` = " + tutorUob;
            AddS.rs = AddS.connect().executeQuery(query_tutor);
            AddS.rs.next();
            String name = AddS.rs.getString("tutor_name");
            System.out.println("\nTutor of the group: " + name + ", Uob number: " + tutorUob);
            
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        AddS.disconnect();
        
        
}

}
    