/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * Driver for the LabClass.
 * 
 * @author Ian Bradley 
 * @version 14-03-2008
 */
public class PATDriver {
	public static void main(String[] args)
	{
		PATTextUI PATTextUI = new PATTextUI();
		PATTextUI.menu();
	}
}