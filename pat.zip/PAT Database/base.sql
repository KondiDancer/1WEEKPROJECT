UPDATE `tutors` SET `group_id` = '1' WHERE `tutors`.`tutor_id` = 1; 

SELECT * FROM groups JOIN students, tutors WHERE groups.group_id=tutors.group_id AND tutors.tutor_id=students.tutor_id AND students.group_id=tutors.group_id;

SELECT * FROM groups JOIN students USING (group_id)

SELECT * FROM groups NATURAL JOIN students, tutors WHERE tutors.tutor_id = students.tutor_id AND tutors.tutor_id = groups.group_id AND students.group_id = groups.group_id;

FINAL:

SELECT groups.group_name, groups.yos, students.student_name, students.student_uob, tutors.tutor_name, tutors.tutor_uob FROM students, tutors, groups WHERE students.group_id = groups.group_id AND tutors.group_id = groups.group_id 

CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
	student_uob INT(8) NOT NULL,
	group_id INT,
	tutor_id INT,
	FOREIGN KEY (group_id) REFERENCES groups(group_id),
	FOREIGN KEY (tutor_id) REFERENCES tutors(tutor_id)
);

CREATE TABLE tutors (
    tutor_id INT AUTO_INCREMENT PRIMARY KEY,
    tutor_name VARCHAR(100) NOT NULL,
	tutor_uob INT(8) NOT NULL,
	group_id INT,
	FOREIGN KEY (group_id) REFERENCES groups(group_id)
);

CREATE TABLE groups (
    group_id INT AUTO_INCREMENT PRIMARY KEY,
    group_name VARCHAR(100) NOT NULL
);