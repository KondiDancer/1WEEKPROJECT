/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PATProject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.*;

/**
 *
 * @author tawalcza
 */
public class AddT {

    static String name;
    static String UBNumber;
    static DbConnect connection = DbConnect.connection;
    static final Scanner user = new Scanner(System.in);

    //Nie przypisuje grup do tutorow(wrzuca nulla do bazy danych), bo tutaj to bez sensu.
    //Zrobi  sie dodawanie grup w menu edycji grup.
    public static void addTutor() {
        String query = "INSERT INTO `tawalcza`.`tutors` (`tutor_uob`, `tutor_name`, `group_name`) VALUES ('" + UBNumber + "', '" + name + "', NULL);";
        connection.executeQuery(query);
    }

    public static void setTutorName() {
        System.out.print("Enter tutor's full name: ");
        String name = user.nextLine();
        System.out.println();

        while (!isNameValid(name)) {
            System.out.println("Please enter a valid name (Full name with upper letters)");
            name = user.nextLine();
        }
        AddT.name = name;
    }

    public static boolean isNameValid(String tutorName) {
        Pattern p = Pattern.compile("[A-Z][a-z]+ [A-Z][a-z]+");
        Matcher m = p.matcher(tutorName);
        return m.matches();
    }

    public static void setTutorUBNumber() {
        System.out.print("Enter tutor uob: ");
        String UBNumber = user.next();
        System.out.println();

        while (!isUBValid(UBNumber)) {
            System.out.println("Tutor uob should be an 8-digital, unique number. Please try again");
            UBNumber = user.next();
        }
        AddT.UBNumber = UBNumber;
    }

    public static List<String> getAllTutorUB() {
        List<String> uob = new ArrayList<>();
        try {
            String query = "SELECT `tutor_uob` FROM `tutors`";
            connection.executeQuery(query);
            while (DbConnect.connection.rs.next()) {
                String UBNumber = connection.rs.getString("tutor_uob");
                uob.add(UBNumber);
            }
        } catch (SQLException sqle) {
            System.out.println(sqle);
        }
        return uob;
    }

    public static boolean isUBValid(String uob) {
        Pattern p = Pattern.compile("[0-9]{8}");
        Matcher m = p.matcher(uob);
        return m.matches();
    }

    public static boolean isUBUnique(String uob) {
        for (int i = 0; i < getAllTutorUB().size(); i++) {
            if (uob.equals(getAllTutorUB().get(i))) {
                return false;
            }
        }
        return true;
    }

}
