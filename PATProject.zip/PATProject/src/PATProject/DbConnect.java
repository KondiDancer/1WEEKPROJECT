package PATProject;

import java.sql.*;
import java.io.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sberk
 */
public class DbConnect {
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    static final DbConnect connection = new DbConnect();
    
    public void estabilish() {      
        File loginDetails = new File("M:\\Desktop\\PATProject\\login.bin");
        FileReader output = null;
        BufferedReader reader = null;                                        
        
        try {
            reader = new BufferedReader(output = new FileReader(loginDetails));
            String username = reader.readLine();
            String password = reader.readLine();
            
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://lamp.scim.brad.ac.uk/kpomian", username, password);
            stmt = conn.createStatement();
        } catch (FileNotFoundException fnfe) {
            System.out.println(fnfe);
        } catch (ClassNotFoundException cnfe) {
            System.out.println(cnfe);
        } catch (SQLException sqle) {
            System.out.println(sqle);
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }
    
    public void disconnect() {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException sqle) {
                System.out.println(sqle);
            }
        }
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException sqle) {
                System.out.println(sqle);
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException sqle) {
                System.out.println(sqle);
            }
        }
    }
    
    public void executeQuery(String query) {
        try {
            rs = stmt.executeQuery(query);
        } catch (SQLException sqle) {
            System.out.println(sqle);
        }
        
    }
}
