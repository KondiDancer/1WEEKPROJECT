/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PATProject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.*;

/**
 *
 * @author tawalcza
 */
public class AddS {
    static String name;
    static String UBNumber;
    static String YearOfStudy;
    static DbConnect connection = DbConnect.connection;
    static final Scanner user = new Scanner(System.in);

    //Nie przypisuje grup ani tutorow do studentow (wrzuca nulla do bazy danych), bo tutaj to bez sensu.
    //Zrobi sie dodawaniu grup w menu edycji, a tutor powinen dodawac sie wtedy sam.
    public static void addStudent() {
        String query = "INSERT INTO `tawalcza`.`students` (`student_uob`, `student_name`, `yos`, `group_name`, `tutor_uob`)"
                + " VALUES ('" + UBNumber + "', '" + name + "', '" + YearOfStudy + "', NULL, NULL);";
        connection.executeQuery(query);
    }

    public static void setStudentYOS() {
        System.out.println("Enter year of study:");
        String studentYOS = user.nextLine();
        
        while (!isYOSValid(studentYOS)) {
            System.out.println("Please enter a year that student is actually on:");
            studentYOS = user.nextLine();
        }
        AddS.YearOfStudy = studentYOS;
    }

    public static boolean isYOSValid(String studentYOS) {
        Pattern p = Pattern.compile("[1-5]");
        Matcher m = p.matcher(studentYOS);
        return m.matches();
    }

    public static void setStudentName() {
        System.out.println("Enter student name:");
        String name = user.nextLine();
        
        while (!isNameValid(name)) {
            System.out.println("Please enter a valid name (Full name with upper letters)");
            name = user.nextLine();
        }
        AddS.name = name;
    }

    public static boolean isNameValid(String studentName) {
        Pattern p = Pattern.compile("[A-Z][a-z]+ [A-Z][a-z]+");
        Matcher m = p.matcher(studentName);
        return m.matches();
    }

    public static void setStudentUB() {
        System.out.println("Enter student uob");
        String studentUB = user.next();
        
        while (isUBValid(studentUB)) {
            System.out.println("Student uob should be an 8-digital, unique number. Please try again:");
            studentUB = user.next();
        }
    }

    public static boolean isUBValid(String uob) {
        Pattern p = Pattern.compile("[0-9]{8}");
        Matcher m = p.matcher(uob);
        return m.matches();
    }

    public static List<String> get_all_student_uob() {
        List<String> uob = new ArrayList<>();
        try {
            String query = "SELECT `student_uob` FROM `students`";
            connection.executeQuery(query);
            while (connection.rs.next()) {
                String UBNumber = connection.rs.getString("student_uob");
                uob.add(UBNumber);
            }
        } catch (SQLException sqle) {
            System.out.println(sqle);
        }
        return uob;
    }

    public static boolean isUBUnique(String uob) {
        for (int i = 0; i < get_all_student_uob().size(); i++) {
            if (uob.equals(get_all_student_uob().get(i))) {
                return false;
            }
        }
        return true;
    }

}
