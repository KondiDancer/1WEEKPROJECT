/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PATProject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Scanner;
import java.util.regex.*;

/**
 *
 * @author tawalcza
 */
public class AddT {

    static Connection con = null;
    static Statement stmt = null;
    static ResultSet rs = null;

    
    //Nie przypisuje grup do tutorow(wrzuca nulla do bazy danych), bo tutaj to bez sensu.
    //Zrobi  sie dodawanie grup w menu edycji grup.
    public static void main(String[] args) {
        String a =get_tutor_uob();
        String b =get_tutor_name();
        connect();
        try {
            String query1 = "INSERT INTO `tawalcza`.`tutors` (`tutor_uob`, `tutor_name`, `group_name`) VALUES ('"+a+"', '"+b+"', NULL);";
        connect().executeUpdate(query1);
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        disconnect();
    }

    public static String get_tutor_name() {
        Scanner user_input = new Scanner(System.in);
        String tutor_name;
        System.out.println("Enter tutor name:");
        tutor_name = user_input.nextLine();
        if (is_name_valid(tutor_name)) {
            return tutor_name;
        }
        do {
            System.out.println("Please enter a valid name (Full name with upper letters)");
            tutor_name = user_input.nextLine();
            if (is_name_valid(tutor_name)) {
                return tutor_name;
            }
        } while (true);
    }

    public static boolean is_name_valid(String tutor_name) {
        Pattern p = Pattern.compile("[A-Z]{1}[a-z]+ [A-Z]{1}[a-z]+");
        Matcher m = p.matcher(tutor_name);
        return m.matches();
    }

    public static String get_tutor_uob() {
        Scanner user_input = new Scanner(System.in);
        String tutor_uob;
        int length;
        System.out.println("Enter tutor uob");
        tutor_uob = user_input.next();
        if (is_uob_valid(tutor_uob) && is_uob_unique(tutor_uob)) {
            return tutor_uob;
        }
        do {
            System.out.println("Tutor uob should be an 8-digital, unique number. Please try again:");
            tutor_uob = user_input.next();
            if (is_uob_valid(tutor_uob) && is_uob_unique(tutor_uob)) {
                return tutor_uob;
            }
        } while (true);
    }

    public static List<String> get_all_tutor_uob() {
        connect();
        List<String> uob = new ArrayList<>();
        try {
            String query_selectuob = "SELECT `tutor_uob` FROM `tutors`";
            rs = connect().executeQuery(query_selectuob);
            while (rs.next()) {
                String PobranyTekst = rs.getString("tutor_uob");
                uob.add(PobranyTekst);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        disconnect();
        return uob;
    }

    public static boolean is_uob_valid(String uob) {
        Scanner user_input = new Scanner(System.in);
        Pattern p = Pattern.compile("[0-9]{8}");
        Matcher m = p.matcher(uob);
        return m.matches();
    }

    public static boolean is_uob_unique(String uob) {
        for (int i = 0; i < get_all_tutor_uob().size(); i++) {
            if (uob.equals(get_all_tutor_uob().get(i))) {
                return false;
            }
        }
        return true;
    }

    public static Statement connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://lamp.scim.brad.ac.uk/tawalcza", "login", "pass");
            stmt = con.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {

            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        return stmt;
    }

    public static void disconnect() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
}
