/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PATProject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Scanner;
import java.util.regex.*;

/**
 *
 * @author tawalcza
 */
public class AddS {

    static Connection con = null;
    static Statement stmt = null;
    static ResultSet rs = null;

    
    //Nie przypisuje grup ani tutorow do studentow (wrzuca nulla do bazy danych), bo tutaj to bez sensu.
    //Zrobi sie dodawaniu grup w menu edycji, a tutor powinen dodawac sie wtedy sam.
    public static void main(String[] args) {
        String a =get_student_uob();
        String b =get_student_name();
        String c =get_student_yos();
        connect();
        try {
            String query1 = "INSERT INTO `dpreciko`.`students` (`student_uob`, `student_name`, `yos`, `group_name`, `tutor_uob`) VALUES ('"+a+"', '"+b+"', '"+c+"', NULL, NULL);;";
        connect().executeUpdate(query1);
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        disconnect();

    }

    public static String get_student_yos() {
        Scanner user_input = new Scanner(System.in);
        String student_yos;
        System.out.println("Enter year of study:");
        student_yos = user_input.nextLine();
        if (is_yos_valid(student_yos)) {
            return student_yos;
        }
        do {
            System.out.println("Please enter a year that student is actually on:");
            student_yos = user_input.nextLine();
            if (is_yos_valid(student_yos)) {
                return student_yos;
            }
        } while (true);
    }

    public static boolean is_yos_valid(String student_yos) {
        Pattern p = Pattern.compile("[1-5]{1}");
        Matcher m = p.matcher(student_yos);
        return m.matches();
    }

    public static String get_student_name() {
        Scanner user_input = new Scanner(System.in);
        String student_name;
        System.out.println("Enter student name:");
        student_name = user_input.nextLine();
        if (is_name_valid(student_name)) {
            return student_name;
        }
        do {
            System.out.println("Please enter a valid name (Full name with upper letters)");
            student_name = user_input.nextLine();
            if (is_name_valid(student_name)) {
                return student_name;
            }
        } while (true);
    }

    public static boolean is_name_valid(String student_name) {
        Pattern p = Pattern.compile("[A-Z]{1}[a-z]+ [A-Z]{1}[a-z]+");
        Matcher m = p.matcher(student_name);
        return m.matches();
    }

    public static String get_student_uob() {
        Scanner user_input = new Scanner(System.in);
        String student_uob;
        int length;
        System.out.println("Enter student uob");
        student_uob = user_input.next();
        if (is_uob_valid(student_uob) && is_uob_unique(student_uob)) {
            return student_uob;
        }
        do {
            System.out.println("Student uob should be an 8-digital, unique number. Please try again:");
            student_uob = user_input.next();
            if (is_uob_valid(student_uob) && is_uob_unique(student_uob)) {
                return student_uob;
            }
        } while (true);
    }

    public static boolean is_uob_valid(String uob) {
        Scanner user_input = new Scanner(System.in);
        Pattern p = Pattern.compile("[0-9]{8}");
        Matcher m = p.matcher(uob);
        return m.matches();
    }

    public static List<String> get_all_student_uob() {
        connect();
        List<String> uob = new ArrayList<>();
        try {
            String query_selectuob = "SELECT `student_uob` FROM `students`";
            rs = connect().executeQuery(query_selectuob);
            while (rs.next()) {
                String PobranyTekst = rs.getString("student_uob");
                uob.add(PobranyTekst);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        disconnect();
        return uob;
    }
    
    public static List<String> get_all_student_groups() {
        connect();
        List<String> groups = new ArrayList<>();
        try {
            String query_selectgroup = "SELECT `group_name` FROM `groups`";
            rs = connect().executeQuery(query_selectgroup);
            while (rs.next()) {
                String name = rs.getString("group_name");
                groups.add(name);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        disconnect();
        return groups;
    }
    public static List<String> get_all_tutors_uob() {
        connect();
        List<String> uob = new ArrayList<>();
        try {
            String query_selectuob = "SELECT `tutor_uob` FROM `tutors`";
            rs = connect().executeQuery(query_selectuob);
            while (rs.next()) {
                String PobranyTekst = rs.getString("tutor_uob");
                uob.add(PobranyTekst);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        disconnect();
        return uob;
    }

    public static boolean is_uob_unique(String uob) {
        for (int i = 0; i < get_all_student_uob().size(); i++) {
            if (uob.equals(get_all_student_uob().get(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isGroupNameUnique(String grnam){
        for (int i = 0; i < get_all_student_groups().size(); i++) {
            if (grnam.equalsIgnoreCase(get_all_student_groups().get(i))) {
                return false;
            }
        }
        return true;
    }

    public static Statement connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://lamp.scim.brad.ac.uk/dpreciko", "login", "pass");
            stmt = con.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {

            Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
        }
        return stmt;
    }

    public static void disconnect() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddS.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
}
